/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import javax.swing.JOptionPane;
/**
 *
 * @author Samukelisiwe Cebekulu ST10489024
 */
public class Letstalk {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MessageManager.populateTestData(); 
        
        Login login = new Login();
        
        // Variables 
        String firstname = "Test";
        String lastname = "User";

        // Register user 
        login.registerUser(firstname, lastname);
        
        // Login user
        boolean status = login.loginUser(firstname, lastname);
        
        // Start the main menu only if login was successful
        if (status) {
            login.signIn();
        } else {
             JOptionPane.showMessageDialog(null, "Application shutting down after login failure.");
        }
    
    }
    
}
