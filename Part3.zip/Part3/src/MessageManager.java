/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author Samukelisiwe Cebekulu ST10489024
 */
public class MessageManager {
    public static ArrayList<Messages> SentMessages = new ArrayList<>();
    public static ArrayList<Messages> DisregardedMessages = new ArrayList<>();
    public static ArrayList<Messages> StoredMessages = new ArrayList<>();
    public static ArrayList<String> MessageHashes = new ArrayList<>();
    
    
    private static final String SENDER_NUMBER = "+27842351024";
    private static class RawMessageData {
        String recipient;
        String message;
        String flag;
        RawMessageData(String r, String m, String f) {
            this.recipient = r;
            this.message = m;
            this.flag = f;
        }
    }
    
    public static void populateTestData() {
       
        SentMessages.clear(); DisregardedMessages.clear(); StoredMessages.clear(); MessageHashes.clear();
        Messages.resetIdCounter(); 

        
        RawMessageData[] testData = {
            new RawMessageData("+27834557896", "Did you get the cake?", "Sent"),           // Message 1
            new RawMessageData("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored"), // Message 2
            new RawMessageData("+27834484567", "Yohoooo, I am at your gate.", "Disregard"), // Message 3
            new RawMessageData("0838884567", "It is dinner time !", "Sent"),              // Message 4
            new RawMessageData("+27838884567", "Ok, I am leaving without you.", "Stored")   // Message 5
        };
        
        for (RawMessageData data : testData) {
          
            Messages msg = new Messages(data.recipient, data.message, data.flag);

            if (null != msg.getFlag()) 
            switch (msg.getFlag()) {
                case "Sent" -> SentMessages.add(msg);
                case "Disregard" -> DisregardedMessages.add(msg);
                case "Stored" -> StoredMessages.add(msg);
                default -> {
                }
            }
            MessageHashes.add(msg.getMessageHash());
        }
        JOptionPane.showMessageDialog(null, "Test data populated successfully. Total messages: " + Messages.idCounter);
    }
    
    //Display Sender and Recipient of All Sent Messages
    public static void displaySentRecipients() {
        StringBuilder sb = new StringBuilder("--- Sent Messages Recipients ---\n");
        for (Messages msg : SentMessages) {
            sb.append("Sender: ").append(SENDER_NUMBER)
              .append(", Recipient: ").append(msg.getRecipient()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Display the Longest Message 
    public static void displayLongestMessage() {
        List<Messages> allMessages = new ArrayList<>();
        allMessages.addAll(SentMessages);
        allMessages.addAll(DisregardedMessages);
        allMessages.addAll(StoredMessages);
        
        if (allMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages available.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Find the longest message object by message length
        Messages longestMsg = allMessages.stream()
            .max(Comparator.comparingInt(msg -> msg.getMessage().length()))
            .orElse(null);

        if (longestMsg != null) {
            String output = "--- Longest Message ---\n"+ "Message: \"" + longestMsg.getMessage() + "\"\n"+ "(Length: " + longestMsg.getMessage().length() + ")";           
            JOptionPane.showMessageDialog(null, output, "Longest Message", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Search for a Message ID
    public static void searchMessageByID() {
        String inputID = JOptionPane.showInputDialog(null, "Enter Message ID to search (1-5):");
        if (inputID == null || inputID.trim().isEmpty()) return;

        try {
            int targetID = Integer.parseInt(inputID);
            
            List<Messages> allMessages = new ArrayList<>();
            allMessages.addAll(SentMessages);
            allMessages.addAll(DisregardedMessages);
            allMessages.addAll(StoredMessages);

            for (Messages msg : allMessages) {
                if (msg.getMessageID() == targetID) {
                    String output = String.format(
                        "--- Message ID Search Result (ID: %d) ---\nRecipient: %s\nMessage: \"%s\"",
                        targetID, msg.getRecipient(), msg.getMessage());
                    JOptionPane.showMessageDialog(null, output, "Message Found", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "Message ID " + targetID + " not found.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid ID format.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Search for all messages sent or stored regarding a particular recipient
    public static void searchMessagesByRecipient() {
        String targetRecipient = JOptionPane.showInputDialog(null, "Enter Recipient number to search (e.g., +27838884567):");
        if (targetRecipient == null || targetRecipient.trim().isEmpty()) return;

        StringBuilder output = new StringBuilder();
        output.append("--- Messages for Recipient: ").append(targetRecipient).append(" ---\n");
        boolean found = false;
        
        ArrayList<Messages> searchPool = new ArrayList<>();
        searchPool.addAll(SentMessages);
        searchPool.addAll(StoredMessages); // Search Sent and Stored

        for (Messages msg : searchPool) {
            if (msg.getRecipient().equals(targetRecipient)) {
                output.append(" - \"").append(msg.getMessage()).append("\"\n");
                found = true;
            }
        }
        
        if (!found) {
            output.append("No Sent or Stored messages found for this recipient.");
        }

        JOptionPane.showMessageDialog(null, output.toString(), "Recipient Search Results", JOptionPane.INFORMATION_MESSAGE);
    }
    
    
    public static void deleteMessageByHash() {
        String targetHash = JOptionPane.showInputDialog(null, "Enter Message Hash to delete:");
        if (targetHash == null || targetHash.trim().isEmpty()) return;

        boolean deleted = false;
        String deletedMessageText = "";

       
        List<ArrayList<Messages>> allMessageArrays = List.of(SentMessages, StoredMessages, DisregardedMessages);
        
        for (ArrayList<Messages> currentList : allMessageArrays) {
            for (int i = 0; i < currentList.size(); i++) {
                Messages msg = currentList.get(i);
                
                if (msg.getMessageHash().equals(targetHash)) {
                    deletedMessageText = msg.getMessage();
                    currentList.remove(i); 
                    MessageHashes.remove(targetHash); 
                    deleted = true;
                    break; 
                }
            }
            if (deleted) break;
        }
        
        if (deleted) {
            String output = String.format("Message \"%s\" successfully deleted.", deletedMessageText);
            JOptionPane.showMessageDialog(null, output, "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Error: Message hash not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
   
    public static void displaySentReport() {
        StringBuilder sb = new StringBuilder("==================================\n");
        sb.append("      SENT MESSAGES REPORT\n");
        sb.append("==================================\n");
        
        for (Messages msg : SentMessages) {
            sb.append("Message Hash: ").append(msg.getMessageHash()).append("\n")
              .append("Recipient:    ").append(msg.getRecipient()).append("\n")
              .append("Message:      \"").append(msg.getMessage()).append("\"\n")
              .append("----------------------------------\n");
        }
        
        JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages Report", JOptionPane.PLAIN_MESSAGE);
    }
}
