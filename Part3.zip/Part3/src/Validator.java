/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.JOptionPane;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 *
 * @author Samukelisiwe Cebekulu ST10489024
 */
public class Validator {
 
    private static final String PASSWORD_PATTERN = 
        "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?]).{8,}$";
    private static final Pattern pattern = Pattern.compile(PASSWORD_PATTERN);

    public boolean checkUserName(String username) {
        // Must contain an underscore and be no more than 5 characters long
        if (username.length() > 5) {
            JOptionPane.showMessageDialog(null, "Username must not exceed 5 characters.");
            return false;
        }
        if (!username.contains("_")) {
            JOptionPane.showMessageDialog(null, "Username must contain an underscore.");
            return false;
        }
        return true;
    }

    // Password validation
    public boolean checkPasswordComplexity(String password) {
        Matcher matcher = pattern.matcher(password);
        if (matcher.matches()) {
            return true;
        } else {
            String requirements = "Password must meet the following requirements:\n" +
                                  "- Minimum 8 characters\n" +
                                  "- At least one uppercase letter\n" +
                                  "- At least one digit (0-9)\n" +
                                  "- At least one special character (!@#$...).";
            JOptionPane.showMessageDialog(null, requirements, "Password Complexity Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}
