/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
/**
 *
 * @author Samukelisiwe Cebekulu ST10489024
 */
public class Messages {
    private final int MessageID;
    private final String Recipient;
    private final String Message;
    private final String Flag;
    private final String MessageHash;
    static int idCounter = 0; 
    
    public Messages(String recipient, String message, String flag) {
        this.MessageID = ++idCounter; 
        this.Recipient = recipient;
        this.Message = message;
        this.Flag = flag;
        this.MessageHash = generateHash(message); 
    }
    
    private String generateHash(String text) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(text.getBytes());
            // Return a Base64 encoded string for safer viewing/storage
            return Base64.getEncoder().encodeToString(hash); 
        } catch (NoSuchAlgorithmException e) {
            return "HASH_ERROR";
        }
    }
    
    public int getMessageID() { return MessageID; }
    public String getRecipient() { return Recipient; }
    public String getMessage() { return Message; }
    public String getFlag() { return Flag; }
    public String getMessageHash() { return MessageHash; }
 
    public static void resetIdCounter() {
        idCounter = 0;
    }
}
