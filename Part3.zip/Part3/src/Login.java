/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.JOptionPane;
/**
 *
 * @author Samukelisiwe Cebekulu ST10489024
 */
public class Login {
    private String username;
    private String password;
    private String cellphone; 
    
    private final Validator validator = new Validator();
    
    //Register User
    public void registerUser(String firstname, String lastname){
        
        String inputUser = JOptionPane.showInputDialog(null, "Enter Username (max 5 chars, requires _):");
        if (inputUser == null || !validator.checkUserName(inputUser)) {
             JOptionPane.showMessageDialog(null, "Registration failed due to invalid username.");
             return;
        }
        
        String inputPass = JOptionPane.showInputDialog(null, "Enter Password (min 8 char,1 special char, upper and lower):");
        if (inputPass == null || !validator.checkPasswordComplexity(inputPass)) {
             JOptionPane.showMessageDialog(null, "Registration failed due to invalid password.");
             return;
        }

        // Successfully registered
        this.username = inputUser;
        this.password = inputPass;
        JOptionPane.showMessageDialog(null, "Registration successful!");
    }
    
    //Login User
    public boolean loginUser(String firstname, String lastname){
        
        String inputUser = JOptionPane.showInputDialog(null, "Enter Username to log in:");
        String inputPass = JOptionPane.showInputDialog(null, "Enter Password to log in:");
        
        boolean status = inputUser.equals(this.username) && inputPass.equals(this.password);
        
        JOptionPane.showMessageDialog(null, returnloginStatus(firstname, lastname, status));
        return status;
    }
    
    //Return Login Status
    public String returnloginStatus(String firstname, String lastname, boolean success){
        // Assuming you collect user names during registerUser for this message
        if (success) {
            return "Login successful! Welcome " + username + ".";
        } else {
            return "Login failed. Incorrect username or password.";
        }
    }

    public void signIn() {
        boolean running = true;
        while (running) {
            String menu = "Welcome to Lets Talk, " + username + "!\n\n" +
                          "1. Display Sender & Recipient \n" +
                          "2. Display Longest Message \n" +
                          "3. Search Message by ID \n" +
                          "4. Search Messages by Recipient \n" +
                          "5. Delete Message by Hash \n" +
                          "6. Display Sent Messages Report \n" +
                          "0. Log Out\n\n" +
                          "Enter your choice:";
                          
            String choiceStr = JOptionPane.showInputDialog(null, menu, "System Options", JOptionPane.PLAIN_MESSAGE);
            if (choiceStr == null) choiceStr = "0"; // Handle cancel/close

            try {
                int choice = Integer.parseInt(choiceStr.trim());
                
                // Calls the static methods in the Messages.java class
                switch (choice) {
                    case 1 -> MessageManager.displaySentRecipients();
                    case 2 -> MessageManager.displayLongestMessage();
                    case 3 -> MessageManager.searchMessageByID();
                    case 4 -> MessageManager.searchMessagesByRecipient();
                    case 5 -> MessageManager.deleteMessageByHash();
                    case 6 -> MessageManager.displaySentReport();
                    case 0 -> running = false;
                    default -> JOptionPane.showMessageDialog(null, "Invalid choice. Please enter a number from 0 to 6.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        JOptionPane.showMessageDialog(null, "Logged out successfully.", "Logout", JOptionPane.INFORMATION_MESSAGE);
    }
}
