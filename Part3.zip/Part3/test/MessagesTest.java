/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Samuk
 */
public class MessagesTest {
    
    public MessagesTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getMessageID method, of class Messages.
     */
    @Test
    public void testGetMessageID() {
        System.out.println("getMessageID");
        Messages instance = null;
        int expResult = 0;
        int result = instance.getMessageID();
        assertEquals(expResult, result);
    }

    /**
     * Test of getRecipient method, of class Messages.
     */
    @Test
    public void testGetRecipient() {
        System.out.println("getRecipient");
        Messages instance = null;
        String expResult = "";
        String result = instance.getRecipient();
        assertEquals(expResult, result);
    }

    /**
     * Test of getMessage method, of class Messages.
     */
    @Test
    public void testGetMessage() {
        System.out.println("getMessage");
        Messages instance = null;
        String expResult = "";
        String result = instance.getMessage();
        assertEquals(expResult, result);
    }

    /**
     * Test of getFlag method, of class Messages.
     */
    @Test
    public void testGetFlag() {
        System.out.println("getFlag");
        Messages instance = null;
        String expResult = "";
        String result = instance.getFlag();
        assertEquals(expResult, result);
    }

    /**
     * Test of getMessageHash method, of class Messages.
     */
    @Test
    public void testGetMessageHash() {
        System.out.println("getMessageHash");
        Messages instance = null;
        String expResult = "";
        String result = instance.getMessageHash();
        assertEquals(expResult, result);
    }

    /**
     * Test of resetIdCounter method, of class Messages.
     */
    @Test
    public void testResetIdCounter() {
        System.out.println("resetIdCounter");
        Messages.resetIdCounter();
    }
    
}
